<?php
// created: 2017-01-16 17:49:53
$dictionary["AOS_Products"]["fields"]["pak_projectkanban_aos_products"] = array (
  'name' => 'pak_projectkanban_aos_products',
  'type' => 'link',
  'relationship' => 'pak_projectkanban_aos_products',
  'source' => 'non-db',
  'module' => 'PAK_ProjectKanban',
  'bean_name' => 'PAK_ProjectKanban',
  'vname' => 'LBL_PAK_PROJECTKANBAN_AOS_PRODUCTS_FROM_PAK_PROJECTKANBAN_TITLE',
);

<?php 
 // created: 2017-01-02 20:58:41
$mod_strings['LBL_TYPE'] = 'type du projet';
$mod_strings['LBL_SHOW_DATETIME'] = 'Show Date';
$mod_strings['LBL_BUDGET'] = 'Budget';
$mod_strings['LBL_WORK_SPACE'] = 'Work space ';
$mod_strings['LBL_FLOOR_FIX'] = 'floor fix';
$mod_strings['LBL_SKY_FIX'] = 'Sky fix';
$mod_strings['LBL_ELECTRICITY'] = 'electricity';
$mod_strings['LBL_SOUND'] = 'sound';
$mod_strings['LBL_LIGHT_PROVIDER_ACCOUNT_ID'] = 'light provider (related Account ID)';
$mod_strings['LBL_LIGHT_PROVIDER'] = 'light provider';
$mod_strings['LBL_MUSIC_PROVIDER_ACCOUNT_ID'] = 'music provider (related Account ID)';
$mod_strings['LBL_MUSIC_PROVIDER'] = 'music provider';
$mod_strings['LBL_TECHNICAL_DETAIL'] = 'Technical detail';
$mod_strings['LBL_DEFRAYED_NIGHT'] = 'defrayed night';
$mod_strings['LBL_DEFRAYED_FOOD'] = 'defrayed food';
$mod_strings['LBL_DEFRAYED_DRINK'] = 'defrayed drink';
$mod_strings['LBL_DEFRAYED_TRAVEL'] = 'defrayed travel';
$mod_strings['LBL_EVENT_INSURANCE'] = 'Event insurance';
$mod_strings['LBL_EVENT_ADVERTISING'] = 'event advertising';
$mod_strings['LBL_DRESSING_ROM'] = 'Dressing rom';
$mod_strings['LBL_CONTACT_ACCOUNT_ID'] = 'Contact (related Account ID)';
$mod_strings['LBL_CONTACT'] = 'Contact';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Contract';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'New Panel 2';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Technic';

?>

<?php 
 // created: 2017-01-02 20:58:40
$mod_strings['LBL_STAGE'] = 'Quote Stage';

?>

<?php 
$app_list_strings['projet_type_list'] = array (
  1 => 'event / show',
  2 => 'Others',
);
<?php
 // created: 2016-12-10 18:25:36
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>
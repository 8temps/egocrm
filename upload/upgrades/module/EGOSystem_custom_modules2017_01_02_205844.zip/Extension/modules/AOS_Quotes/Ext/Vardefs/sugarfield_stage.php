<?php
 // created: 2016-12-14 10:59:02
$dictionary['AOS_Quotes']['fields']['stage']['default']='Draft';
$dictionary['AOS_Quotes']['fields']['stage']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['stage']['massupdate']='1';
$dictionary['AOS_Quotes']['fields']['stage']['options']='quote_stage_dom';
$dictionary['AOS_Quotes']['fields']['stage']['merge_filter']='disabled';

 ?>
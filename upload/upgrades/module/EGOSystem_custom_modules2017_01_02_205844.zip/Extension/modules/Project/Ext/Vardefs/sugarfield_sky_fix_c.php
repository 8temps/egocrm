<?php
 // created: 2016-12-14 19:10:08
$dictionary['Project']['fields']['sky_fix_c']['inline_edit']='1';
$dictionary['Project']['fields']['sky_fix_c']['labelValue']='Sky fix';

 ?>
<?php
 // created: 2016-12-14 19:08:15
$dictionary['Project']['fields']['work_space_c']['inline_edit']='1';
$dictionary['Project']['fields']['work_space_c']['labelValue']='Work space ';

 ?>
<?php
 // created: 2016-12-14 19:11:22
$dictionary['Project']['fields']['sound_c']['inline_edit']='1';
$dictionary['Project']['fields']['sound_c']['labelValue']='sound';

 ?>
<?php
 // created: 2016-12-14 19:18:53
$dictionary['Project']['fields']['defrayed_night_c']['inline_edit']='1';
$dictionary['Project']['fields']['defrayed_night_c']['labelValue']='defrayed night';

 ?>
<?php
 // created: 2016-12-14 19:06:01
$dictionary['Project']['fields']['currency_id']['inline_edit']=1;

 ?>
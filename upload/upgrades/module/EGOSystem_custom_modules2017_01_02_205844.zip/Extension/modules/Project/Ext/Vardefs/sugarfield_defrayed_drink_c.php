<?php
 // created: 2016-12-14 19:22:29
$dictionary['Project']['fields']['defrayed_drink_c']['inline_edit']='1';
$dictionary['Project']['fields']['defrayed_drink_c']['labelValue']='defrayed drink';

 ?>
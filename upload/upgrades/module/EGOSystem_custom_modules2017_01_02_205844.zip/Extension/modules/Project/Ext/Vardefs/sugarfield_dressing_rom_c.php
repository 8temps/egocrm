<?php
 // created: 2016-12-14 19:29:54
$dictionary['Project']['fields']['dressing_rom_c']['inline_edit']='1';
$dictionary['Project']['fields']['dressing_rom_c']['labelValue']='Dressing rom';

 ?>
<?php
 // created: 2016-12-14 19:09:47
$dictionary['Project']['fields']['floor_fix_c']['inline_edit']='1';
$dictionary['Project']['fields']['floor_fix_c']['labelValue']='floor fix';

 ?>
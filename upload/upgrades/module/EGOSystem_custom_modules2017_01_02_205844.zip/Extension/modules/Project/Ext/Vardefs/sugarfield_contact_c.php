<?php
 // created: 2016-12-14 19:30:44
$dictionary['Project']['fields']['contact_c']['inline_edit']='1';
$dictionary['Project']['fields']['contact_c']['labelValue']='Contact';

 ?>
<?php
 // created: 2016-12-14 19:24:39
$dictionary['Project']['fields']['event_advertising_c']['inline_edit']='1';
$dictionary['Project']['fields']['event_advertising_c']['labelValue']='event advertising';

 ?>
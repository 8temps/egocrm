<?php
 // created: 2016-12-14 19:15:02
$dictionary['Project']['fields']['music_provider_c']['inline_edit']='1';
$dictionary['Project']['fields']['music_provider_c']['labelValue']='music provider';

 ?>
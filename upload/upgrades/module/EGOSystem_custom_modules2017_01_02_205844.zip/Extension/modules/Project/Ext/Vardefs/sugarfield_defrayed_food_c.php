<?php
 // created: 2016-12-14 19:22:11
$dictionary['Project']['fields']['defrayed_food_c']['inline_edit']='1';
$dictionary['Project']['fields']['defrayed_food_c']['labelValue']='defrayed food';

 ?>
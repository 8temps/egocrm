<?php
 // created: 2016-12-14 19:16:26
$dictionary['Project']['fields']['technical_detail_c']['inline_edit']='1';
$dictionary['Project']['fields']['technical_detail_c']['labelValue']='Technical detail';

 ?>
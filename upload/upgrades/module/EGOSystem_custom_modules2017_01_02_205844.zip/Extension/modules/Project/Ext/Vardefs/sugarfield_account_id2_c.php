<?php
 // created: 2016-12-14 19:30:43
$dictionary['Project']['fields']['account_id2_c']['inline_edit']=1;

 ?>
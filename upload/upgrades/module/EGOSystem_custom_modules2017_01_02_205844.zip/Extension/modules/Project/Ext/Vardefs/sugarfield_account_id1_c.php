<?php
 // created: 2016-12-14 19:14:33
$dictionary['Project']['fields']['account_id1_c']['inline_edit']=1;

 ?>
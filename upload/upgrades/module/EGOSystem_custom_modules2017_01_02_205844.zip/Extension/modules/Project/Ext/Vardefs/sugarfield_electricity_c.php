<?php
 // created: 2016-12-14 19:10:44
$dictionary['Project']['fields']['electricity_c']['inline_edit']='1';
$dictionary['Project']['fields']['electricity_c']['labelValue']='electricity';

 ?>
<?php
 // created: 2016-12-14 19:04:50
$dictionary['Project']['fields']['show_datetime_c']['inline_edit']='1';
$dictionary['Project']['fields']['show_datetime_c']['labelValue']='Show Date';

 ?>
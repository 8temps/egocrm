<?php
 // created: 2016-12-10 18:25:36
$dictionary['Project']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>
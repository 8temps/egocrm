<?php
 // created: 2016-12-14 19:02:01
$dictionary['Project']['fields']['type_c']['inline_edit']='1';
$dictionary['Project']['fields']['type_c']['labelValue']='type du projet';

 ?>
<?php
 // created: 2016-12-14 19:22:49
$dictionary['Project']['fields']['defrayed_travel_c']['inline_edit']='1';
$dictionary['Project']['fields']['defrayed_travel_c']['labelValue']='defrayed travel';

 ?>
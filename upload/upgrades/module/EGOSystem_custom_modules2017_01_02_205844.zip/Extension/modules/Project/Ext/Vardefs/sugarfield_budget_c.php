<?php
 // created: 2016-12-14 19:06:01
$dictionary['Project']['fields']['budget_c']['inline_edit']='1';
$dictionary['Project']['fields']['budget_c']['labelValue']='Budget';

 ?>
<?php
 // created: 2016-12-14 19:24:08
$dictionary['Project']['fields']['event_insurance_c']['inline_edit']='1';
$dictionary['Project']['fields']['event_insurance_c']['labelValue']='Event insurance';

 ?>
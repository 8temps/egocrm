<?php
 // created: 2016-12-14 19:13:52
$dictionary['Project']['fields']['account_id_c']['inline_edit']=1;

 ?>
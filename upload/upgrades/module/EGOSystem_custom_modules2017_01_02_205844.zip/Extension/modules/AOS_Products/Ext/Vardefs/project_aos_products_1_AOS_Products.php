<?php
// created: 2016-12-14 19:31:26
$dictionary["AOS_Products"]["fields"]["project_aos_products_1"] = array (
  'name' => 'project_aos_products_1',
  'type' => 'link',
  'relationship' => 'project_aos_products_1',
  'source' => 'non-db',
  'module' => 'Project',
  'bean_name' => 'Project',
  'vname' => 'LBL_PROJECT_AOS_PRODUCTS_1_FROM_PROJECT_TITLE',
);

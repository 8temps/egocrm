<?php
 // created: 2017-01-03 12:05:28
$layout_defs["EGO_Courses"]["subpanel_setup"]['ego_courses_leads'] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_EGO_COURSES_LEADS_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'ego_courses_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);

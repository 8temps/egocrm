<?php
// created: 2017-01-03 12:05:28
$dictionary["EGO_Courses"]["fields"]["ego_courses_leads"] = array (
  'name' => 'ego_courses_leads',
  'type' => 'link',
  'relationship' => 'ego_courses_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_EGO_COURSES_LEADS_FROM_LEADS_TITLE',
);

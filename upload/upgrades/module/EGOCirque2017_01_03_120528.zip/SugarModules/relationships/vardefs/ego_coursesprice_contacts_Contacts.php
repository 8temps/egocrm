<?php
// created: 2017-01-03 12:05:28
$dictionary["Contact"]["fields"]["ego_coursesprice_contacts"] = array (
  'name' => 'ego_coursesprice_contacts',
  'type' => 'link',
  'relationship' => 'ego_coursesprice_contacts',
  'source' => 'non-db',
  'module' => 'EGO_Coursesprice',
  'bean_name' => 'EGO_Coursesprice',
  'vname' => 'LBL_EGO_COURSESPRICE_CONTACTS_FROM_EGO_COURSESPRICE_TITLE',
);

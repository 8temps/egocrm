<?php
// created: 2017-01-03 12:05:28
$dictionary["Contact"]["fields"]["ego_courses_contacts"] = array (
  'name' => 'ego_courses_contacts',
  'type' => 'link',
  'relationship' => 'ego_courses_contacts',
  'source' => 'non-db',
  'module' => 'EGO_Courses',
  'bean_name' => 'EGO_Courses',
  'vname' => 'LBL_EGO_COURSES_CONTACTS_FROM_EGO_COURSES_TITLE',
);

<?php
// created: 2017-01-03 12:05:28
$dictionary["EGO_Academicyear"]["fields"]["ego_academicyear_ego_coursesprice"] = array (
  'name' => 'ego_academicyear_ego_coursesprice',
  'type' => 'link',
  'relationship' => 'ego_academicyear_ego_coursesprice',
  'source' => 'non-db',
  'module' => 'EGO_Coursesprice',
  'bean_name' => 'EGO_Coursesprice',
  'side' => 'right',
  'vname' => 'LBL_EGO_ACADEMICYEAR_EGO_COURSESPRICE_FROM_EGO_COURSESPRICE_TITLE',
);

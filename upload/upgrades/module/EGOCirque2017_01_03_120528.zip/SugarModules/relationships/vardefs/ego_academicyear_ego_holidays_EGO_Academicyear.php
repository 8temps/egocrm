<?php
// created: 2017-01-03 12:05:28
$dictionary["EGO_Academicyear"]["fields"]["ego_academicyear_ego_holidays"] = array (
  'name' => 'ego_academicyear_ego_holidays',
  'type' => 'link',
  'relationship' => 'ego_academicyear_ego_holidays',
  'source' => 'non-db',
  'module' => 'EGO_Holidays',
  'bean_name' => 'EGO_Holidays',
  'side' => 'right',
  'vname' => 'LBL_EGO_ACADEMICYEAR_EGO_HOLIDAYS_FROM_EGO_HOLIDAYS_TITLE',
);

<?php
// created: 2017-01-03 12:05:28
$dictionary["EGO_Coursesprice"]["fields"]["ego_coursesprice_contacts"] = array (
  'name' => 'ego_coursesprice_contacts',
  'type' => 'link',
  'relationship' => 'ego_coursesprice_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_EGO_COURSESPRICE_CONTACTS_FROM_CONTACTS_TITLE',
);

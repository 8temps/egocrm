<?php
// created: 2017-01-03 12:05:28
$dictionary["EGO_Academicyear"]["fields"]["ego_academicyear_ego_courses"] = array (
  'name' => 'ego_academicyear_ego_courses',
  'type' => 'link',
  'relationship' => 'ego_academicyear_ego_courses',
  'source' => 'non-db',
  'module' => 'EGO_Courses',
  'bean_name' => 'EGO_Courses',
  'side' => 'right',
  'vname' => 'LBL_EGO_ACADEMICYEAR_EGO_COURSES_FROM_EGO_COURSES_TITLE',
);

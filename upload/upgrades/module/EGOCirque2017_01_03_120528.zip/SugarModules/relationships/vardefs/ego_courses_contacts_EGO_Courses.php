<?php
// created: 2017-01-03 12:05:28
$dictionary["EGO_Courses"]["fields"]["ego_courses_contacts"] = array (
  'name' => 'ego_courses_contacts',
  'type' => 'link',
  'relationship' => 'ego_courses_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_EGO_COURSES_CONTACTS_FROM_CONTACTS_TITLE',
);

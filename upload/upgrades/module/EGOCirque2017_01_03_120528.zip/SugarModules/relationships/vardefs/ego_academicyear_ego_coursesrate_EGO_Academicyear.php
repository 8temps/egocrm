<?php
// created: 2017-01-03 12:05:28
$dictionary["EGO_Academicyear"]["fields"]["ego_academicyear_ego_coursesrate"] = array (
  'name' => 'ego_academicyear_ego_coursesrate',
  'type' => 'link',
  'relationship' => 'ego_academicyear_ego_coursesrate',
  'source' => 'non-db',
  'module' => 'EGO_Coursesrate',
  'bean_name' => 'EGO_Coursesrate',
  'side' => 'right',
  'vname' => 'LBL_EGO_ACADEMICYEAR_EGO_COURSESRATE_FROM_EGO_COURSESRATE_TITLE',
);

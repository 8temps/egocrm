{
    "sEmptyTable":     "No hay datos disponibles en la tabla.",
    "sInfo":           "Mostrando desde _START_ hasta _END_ de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando 0 a 0 de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "Mostrando _MENU_ registros",
    "sLoadingRecords": "Cargando...",
    "sProcessing":     "Procesando...",
    "sSearch":         "Buscar:",
    "sZeroRecords":    "No se encontraron resultados",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Último",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": activar el ordenado de columna ascendentemente",
        "sSortDescending": ": activar el ordenado de columna descendentemente"
    }
}
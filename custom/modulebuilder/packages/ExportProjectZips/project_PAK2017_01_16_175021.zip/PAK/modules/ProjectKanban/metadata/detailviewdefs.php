<?php
$module_name = 'PAK_ProjectKanban';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL3' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'status',
            'studio' => 'visible',
            'label' => 'LBL_STATUS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'contact',
            'studio' => 'visible',
            'label' => 'LBL_CONTACT',
          ),
          1 => 'assigned_user_name',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'type_project',
            'studio' => 'visible',
            'label' => 'LBL_TYPE_PROJECT',
          ),
          1 => 
          array (
            'name' => 'estimated_start_date',
            'label' => 'LBL_ESTIMATED_START_DATE ',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'estimated_deadline_date',
            'label' => 'LBL_ESTIMATED_DEADLINE_DATE ',
          ),
          1 => 
          array (
            'name' => 'estimated_end_date',
            'label' => 'LBL_ESTIMATED_END_DATE ',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'budget',
            'label' => 'LBL_BUDGET',
          ),
          1 => 
          array (
            'name' => 'currency_id',
            'studio' => 'visible',
            'label' => 'LBL_CURRENCY',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'income',
            'label' => 'LBL_INCOME',
          ),
          1 => 
          array (
            'name' => 'expenses',
            'label' => 'LBL_EXPENSES',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'cod_kanboard',
            'label' => 'LBL_COD_KANBOARD',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'web',
            'label' => 'LBL_WEB',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'dropbox',
            'label' => 'LBL_DROPBOX',
          ),
          1 => 
          array (
            'name' => 'gdrive',
            'label' => 'LBL_GDRIVE',
          ),
        ),
        9 => 
        array (
          0 => 'description',
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'dressing_room',
            'label' => 'LBL_DRESSING_ROOM',
          ),
          1 => 
          array (
            'name' => 'behind_scene',
            'label' => 'LBL_BEHIND_SCENE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'electricity',
            'label' => 'LBL_ELECTRICITY',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'floor_fix',
            'label' => 'LBL_FLOOR_FIX',
          ),
          1 => 
          array (
            'name' => 'sky_fix',
            'label' => 'LBL_SKY_FIX',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'sound',
            'label' => 'LBL_SOUND',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'light',
            'label' => 'LBL_LIGHT',
          ),
          1 => 
          array (
            'name' => 'provider_light',
            'studio' => 'visible',
            'label' => 'LBL_PROVIDER_LIGHT',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'technical_detail',
            'studio' => 'visible',
            'label' => 'LBL_TECHNICAL_DETAIL',
          ),
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'defrayed_drink',
            'label' => 'LBL_DEFRAYED_DRINK',
          ),
          1 => 
          array (
            'name' => 'defrayed_food',
            'label' => 'LBL_DEFRAYED_FOOD',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'defrayed_travel',
            'label' => 'LBL_DEFRAYED_TRAVEL',
          ),
          1 => 
          array (
            'name' => 'defrayed_night',
            'label' => 'LBL_DEFRAYED_NIGHT',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'defrayed_advertising',
            'label' => 'LBL_DEFRAYED_ADVERTISING',
          ),
          1 => 
          array (
            'name' => 'event_insurance',
            'label' => 'LBL_EVENT_INSURANCE',
          ),
        ),
      ),
    ),
  ),
);
?>

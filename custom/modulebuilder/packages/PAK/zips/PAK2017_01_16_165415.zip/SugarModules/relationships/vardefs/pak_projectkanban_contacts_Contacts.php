<?php
// created: 2017-01-16 16:54:15
$dictionary["Contact"]["fields"]["pak_projectkanban_contacts"] = array (
  'name' => 'pak_projectkanban_contacts',
  'type' => 'link',
  'relationship' => 'pak_projectkanban_contacts',
  'source' => 'non-db',
  'module' => 'PAK_ProjectKanban',
  'bean_name' => 'PAK_ProjectKanban',
  'vname' => 'LBL_PAK_PROJECTKANBAN_CONTACTS_FROM_PAK_PROJECTKANBAN_TITLE',
);

<?php
// created: 2017-01-16 16:54:15
$dictionary["PAK_ProjectKanban"]["fields"]["pak_projectkanban_pak_doodle"] = array (
  'name' => 'pak_projectkanban_pak_doodle',
  'type' => 'link',
  'relationship' => 'pak_projectkanban_pak_doodle',
  'source' => 'non-db',
  'module' => 'PAK_Doodle',
  'bean_name' => 'PAK_Doodle',
  'side' => 'right',
  'vname' => 'LBL_PAK_PROJECTKANBAN_PAK_DOODLE_FROM_PAK_DOODLE_TITLE',
);

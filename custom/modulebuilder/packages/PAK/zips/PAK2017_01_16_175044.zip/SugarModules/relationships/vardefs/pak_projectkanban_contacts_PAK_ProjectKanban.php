<?php
// created: 2017-01-16 17:50:44
$dictionary["PAK_ProjectKanban"]["fields"]["pak_projectkanban_contacts"] = array (
  'name' => 'pak_projectkanban_contacts',
  'type' => 'link',
  'relationship' => 'pak_projectkanban_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_PAK_PROJECTKANBAN_CONTACTS_FROM_CONTACTS_TITLE',
);

<?php
// created: 2017-01-16 17:50:44
$dictionary["PAK_ProjectKanban"]["fields"]["pak_projectkanban_aos_products"] = array (
  'name' => 'pak_projectkanban_aos_products',
  'type' => 'link',
  'relationship' => 'pak_projectkanban_aos_products',
  'source' => 'non-db',
  'module' => 'AOS_Products',
  'bean_name' => 'AOS_Products',
  'vname' => 'LBL_PAK_PROJECTKANBAN_AOS_PRODUCTS_FROM_AOS_PRODUCTS_TITLE',
);
